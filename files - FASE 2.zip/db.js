// ============================================================
// config/db.js — Conexão com PostgreSQL
// ============================================================
// Usa um Pool de conexões: em vez de abrir e fechar uma conexão
// a cada requisição, o Pool mantém conexões abertas e reutiliza.
// Isso é muito mais rápido para 70 usuários simultâneos.
// ============================================================

import pg from 'pg';
import dotenv from 'dotenv';

dotenv.config();

const { Pool } = pg;

const pool = new Pool({
  host:     process.env.DB_HOST     || 'localhost',
  port:     parseInt(process.env.DB_PORT || '5432'),
  database: process.env.DB_NAME     || 'boxer_requisicoes',
  user:     process.env.DB_USER     || 'postgres',
  password: process.env.DB_PASSWORD || '',
  // Máximo de conexões simultâneas no pool
  max: 10,
  // Tempo máximo que uma conexão fica ociosa antes de fechar (ms)
  idleTimeoutMillis: 30000,
  // Tempo máximo para obter uma conexão do pool (ms)
  connectionTimeoutMillis: 2000,
});

// Testa a conexão ao iniciar e avisa se algo estiver errado
pool.on('connect', () => {
  if (process.env.NODE_ENV !== 'production') {
    console.log('✅ Conectado ao PostgreSQL');
  }
});

pool.on('error', (err) => {
  console.error('❌ Erro no pool do PostgreSQL:', err.message);
});

// Função auxiliar para executar queries
// Uso: const result = await query('SELECT * FROM usuarios WHERE id = $1', [id])
export async function query(text, params) {
  const start = Date.now();
  try {
    const result = await pool.query(text, params);
    if (process.env.NODE_ENV === 'development') {
      const duration = Date.now() - start;
      if (duration > 200) {
        console.warn(`⚠️  Query lenta (${duration}ms): ${text.slice(0, 60)}...`);
      }
    }
    return result;
  } catch (err) {
    console.error('Erro na query:', { text: text.slice(0, 100), params, error: err.message });
    throw err;
  }
}

// Função para transações — garante que múltiplas operações
// sejam atômicas (todas funcionam ou nenhuma é salva)
// Uso:
//   await transaction(async (client) => {
//     await client.query('INSERT INTO requisicoes ...')
//     await client.query('INSERT INTO historico_status ...')
//   })
export async function transaction(callback) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await callback(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

export default pool;
