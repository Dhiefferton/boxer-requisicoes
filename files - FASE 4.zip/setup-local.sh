#!/bin/bash
# ============================================================
# setup-local.sh — Configuração automática para desenvolvimento
# Boxer Sistema de Requisição de Materiais
# ============================================================
# Execute com: bash setup-local.sh
# ============================================================

set -e  # Para se qualquer comando falhar

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║   Boxer Requisições — Setup Local        ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# ── Verificar pré-requisitos ─────────────────────────────────
echo "▶ Verificando pré-requisitos..."

if ! command -v node &>/dev/null; then
  echo "❌ Node.js não encontrado. Instale em https://nodejs.org"
  exit 1
fi

NODE_VERSION=$(node --version | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
  echo "❌ Node.js $NODE_VERSION encontrado. Necessário Node.js 18+."
  exit 1
fi

if ! command -v psql &>/dev/null; then
  echo "❌ PostgreSQL não encontrado. Instale em https://www.postgresql.org/download"
  exit 1
fi

echo "✅ Node.js $(node --version) OK"
echo "✅ PostgreSQL $(psql --version | head -1) OK"

# ── Variáveis ────────────────────────────────────────────────
read -p "
Nome do banco de dados [boxer_requisicoes]: " DB_NAME
DB_NAME=${DB_NAME:-boxer_requisicoes}

read -p "Usuário do PostgreSQL [postgres]: " DB_USER
DB_USER=${DB_USER:-postgres}

read -sp "Senha do PostgreSQL: " DB_PASSWORD
echo ""

# ── Criar banco ──────────────────────────────────────────────
echo ""
echo "▶ Criando banco de dados '$DB_NAME'..."
PGPASSWORD=$DB_PASSWORD psql -U "$DB_USER" -c "CREATE DATABASE $DB_NAME;" 2>/dev/null || \
  echo "  (banco já existe, continuando)"

# ── Migrations ───────────────────────────────────────────────
echo "▶ Executando migrations..."
PSQL="PGPASSWORD=$DB_PASSWORD psql -U $DB_USER -d $DB_NAME"

eval "$PSQL -f database/migrations/001_departamentos_usuarios.sql" && echo "  ✅ 001 OK"
eval "$PSQL -f database/migrations/002_catalogo_materiais.sql"    && echo "  ✅ 002 OK"
eval "$PSQL -f database/migrations/003_requisicoes.sql"           && echo "  ✅ 003 OK"
eval "$PSQL -f database/migrations/004_logs.sql"                  && echo "  ✅ 004 OK"
eval "$PSQL -f database/COMO_EXECUTAR.sql"                        && echo "  ✅ Views OK"

# ── Backend .env ─────────────────────────────────────────────
echo ""
echo "▶ Criando arquivo backend/.env..."
JWT_SECRET=$(node -e "console.log(require('crypto').randomBytes(64).toString('hex'))")

cat > backend/.env << EOF
PORT=3001
NODE_ENV=development
DB_HOST=localhost
DB_PORT=5432
DB_NAME=$DB_NAME
DB_USER=$DB_USER
DB_PASSWORD=$DB_PASSWORD
JWT_SECRET=$JWT_SECRET
JWT_EXPIRES_IN=8h
CORS_ORIGIN=http://localhost:5173
EOF
echo "  ✅ .env criado com JWT_SECRET gerado automaticamente"

# ── Instalar dependências ────────────────────────────────────
echo ""
echo "▶ Instalando dependências do backend..."
cd backend && npm install --silent && cd ..
echo "  ✅ Backend OK"

echo "▶ Instalando dependências do frontend..."
cd frontend && npm install --silent && cd ..
echo "  ✅ Frontend OK"

# ── Gerar hashes e seed ──────────────────────────────────────
echo ""
echo "▶ Gerando senhas para o seed..."
cd backend
HASHES=$(node scripts/generate-seed-passwords.js 2>/dev/null)

# Extrair os 3 hashes gerados
HASH_ADMIN=$(echo "$HASHES"     | grep -A1 "admin:"       | grep "Hash:" | awk '{print $2}')
HASH_OPER=$(echo "$HASHES"      | grep -A1 "operador:"    | grep "Hash:" | awk '{print $2}')
HASH_COLAB=$(echo "$HASHES"     | grep -A1 "colaborador:" | grep "Hash:" | awk '{print $2}')
cd ..

# Substituir no seed
SEED_FILE="database/seeds/001_dados_iniciais.sql"
sed -i.bak \
  "s|\$2b\$10\$YourHashHere.ReplaceThisWithRealBcryptHash.ForSecurity|PLACEHOLDER|g" \
  "$SEED_FILE"

# Substituição posicional (admin = 1º, operador = 2º, colaborador = 3º)
COUNTER=0
while IFS= read -r line; do
  if echo "$line" | grep -q "PLACEHOLDER"; then
    COUNTER=$((COUNTER + 1))
    case $COUNTER in
      1) echo "${line/PLACEHOLDER/$HASH_ADMIN}" ;;
      2) echo "${line/PLACEHOLDER/$HASH_OPER}"  ;;
      3) echo "${line/PLACEHOLDER/$HASH_COLAB}" ;;
      *) echo "$line" ;;
    esac
  else
    echo "$line"
  fi
done < "$SEED_FILE" > "${SEED_FILE}.tmp" && mv "${SEED_FILE}.tmp" "$SEED_FILE"
rm -f "${SEED_FILE}.bak"

echo "  ✅ Hashes gerados e aplicados ao seed"

echo "▶ Carregando dados iniciais..."
eval "PGPASSWORD=$DB_PASSWORD psql -U $DB_USER -d $DB_NAME -f database/seeds/001_dados_iniciais.sql" \
  && echo "  ✅ Seed carregado: 48 materiais, 8 departamentos, 3 usuários"

# ── Concluído ────────────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════╗"
echo "║           ✅ Setup concluído!            ║"
echo "╚══════════════════════════════════════════╝"
echo ""
echo "Para rodar o sistema, abra 2 terminais:"
echo ""
echo "  Terminal 1 (backend):"
echo "    cd backend && npm run dev"
echo ""
echo "  Terminal 2 (frontend):"
echo "    cd frontend && npm run dev"
echo ""
echo "Acesse: http://localhost:5173"
echo ""
echo "Credenciais de acesso:"
echo "  Admin:        admin@boxer.com.br / boxer@2025"
echo "  Operador:     operador@boxer.com.br / boxer@2025"
echo "  Colaborador:  colaborador@boxer.com.br / boxer@2025"
echo ""
