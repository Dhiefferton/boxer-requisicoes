# Roadmap — Evoluções Futuras

Este documento registra as melhorias planejadas após o MVP, organizadas por impacto e esforço.

---

## Fase 2 — Operação (1 a 2 meses após o lançamento)

Melhorias que surgirão naturalmente do uso real.

**Notificação por e-mail**
Quando o status de uma requisição muda, o solicitante recebe um e-mail automático.
- Implementar com Nodemailer no backend
- Configurar SMTP (Gmail, SendGrid ou servidor próprio)
- Template simples: "Sua requisição #42 foi entregue"

**Painel de relatórios para admin**
Visão gerencial dos dados do sistema.
- Materiais mais solicitados
- Volume por departamento
- Tempo médio de separação
- Requisições por período
- Implementar com queries SQL agregadas + recharts no frontend

**PWA — instalar no celular**
Permite que os colaboradores instalem o sistema na tela inicial sem app store.
- Adicionar `manifest.json` e service worker
- Ícone e splash screen da Boxer
- Funciona offline para visualizar o histórico

---

## Fase 3 — Integrações (prazo a definir com TI)

**ERP Zen API**
Os stubs já estão criados em `backend/src/integrations/erpZen.js`.
- Sincronizar estoque automaticamente ao aprovar uma requisição
- Buscar dados de materiais diretamente do ERP
- Ativar via `ERP_ZEN_ATIVO=true` no `.env`

**Pipefy API**
Os stubs já estão criados em `backend/src/integrations/pipefy.js`.
- Criar card no Pipefy ao submeter requisição
- Mover o card de fase conforme o status avança
- Ativar via `PIPEFY_ATIVO=true` no `.env`

---

## Fase 4 — Funcionalidades avançadas

**Aprovação em dois níveis**
Para requisições acima de certo valor ou quantidade.
- Gestor do departamento aprova antes de ir para separação
- Novo status intermediário: `aguardando_aprovacao`
- Notificação ao gestor por e-mail

**Upload de comprovante de entrega**
O operador fotografa a entrega para fechar o ciclo com evidência.
- Campo de upload de imagem na mudança para status "entregue"
- Armazenamento no S3 ou equivalente
- Visualização no histórico do colaborador

**Requisição recorrente**
Para materiais que são pedidos sempre com a mesma frequência.
- Salvar um pedido como "favorito"
- Repetir com um clique, editando apenas a data de necessidade

**Catálogo com imagens**
Cards dos materiais com foto para facilitar a identificação.
- Campo de URL de imagem na tabela `materiais`
- Exibição no card do catálogo
- Upload via painel admin

---

## Notas técnicas para cada fase

Todas as evoluções são aditivas — nenhuma requer reescrever o que foi feito.
A arquitetura foi pensada para crescer sem quebrar o que já funciona.

Para cada nova funcionalidade: criar a migration SQL correspondente, implementar as rotas no backend, criar os componentes no frontend. O padrão está estabelecido e pode ser seguido por qualquer desenvolvedor que entre no projeto.
